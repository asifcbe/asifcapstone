import React from 'react'

function Category() {
  return (
    <div>Category</div>
  )
}

export default Category